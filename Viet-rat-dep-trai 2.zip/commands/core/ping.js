const ms = require('ms');

module.exports = {
    name: 'ping',
    aliases: ['ms'],
    utilisation: '{prefix}ping',

    run : async(client, message) => {
        message.channel.send(`Tốc Độ Api Là: **${client.ws.ping}ms** 🏓`);
    },
};
